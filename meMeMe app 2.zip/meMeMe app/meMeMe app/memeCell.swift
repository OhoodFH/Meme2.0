//
//  memeCell.swift
//  meMeMe app
//
//  Created by Ohood Fahd on 12/2/17.
//  Copyright © 2017 Ohood Fahd. All rights reserved.
//

import UIKit

class MemeCollectionViewCell: UICollectionViewCell{
    
    //Mark: Outlets
    
    @IBOutlet weak var memeImageView: UIImageView!

    
}
