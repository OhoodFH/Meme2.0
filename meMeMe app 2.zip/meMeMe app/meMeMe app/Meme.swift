//
//  Meme.swift
//  meMeMe app
//
//  Created by Ohood Fahd on 11/10/17.
//  Copyright © 2017 Ohood Fahd. All rights reserved.
//

import Foundation
import UIKit

//Meme struct
struct Meme {
    var topText: String?
    var bottomText: String?
    var originalImage: UIImage?
    var memedImage: UIImage
    
}

