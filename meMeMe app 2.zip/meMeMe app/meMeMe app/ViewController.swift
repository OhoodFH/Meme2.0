//
//  ViewController.swift
//  meMeMe app
//
//  Created by Ohood Fahd on 11/6/17.
//  Copyright © 2017 Ohood Fahd. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    @IBOutlet weak var imagePickerView: UIImageView!
    
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    
    @IBOutlet weak var bottomTextField: UITextField!
    @IBOutlet weak var topTextField: UITextField!
    
    @IBOutlet weak var shareImage: UIBarButtonItem!
    
    @IBOutlet weak var navBar: UINavigationItem!
    
    @IBOutlet weak var bottomToolBar: UIToolbar!
    
    let textStyle:[String:Any] = [
        NSAttributedStringKey.strokeColor.rawValue: UIColor.black,
        NSAttributedStringKey.foregroundColor.rawValue: UIColor.white,
        NSAttributedStringKey.font.rawValue: UIFont (name: "Impact", size: 50)!,
        NSAttributedStringKey.strokeWidth.rawValue: -3.5
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        
        configure(Text: "TOP", style: textStyle, textField: self.topTextField)
        configure(Text: "BOTTOM", style: textStyle, textField: self.bottomTextField)
        
        self.topTextField.textAlignment = .center
        self.bottomTextField.textAlignment = .center
        
        shareImage.isEnabled = self.imagePickerView.image != nil
        
        self.navigationController?.setNavigationBarHidden(false, animated: false)

    }
    
    
    func configure(Text:String, style: [String: Any], textField: UITextField)
    {
        textField.text = Text
        textField.textAlignment = .center
        textField.delegate = self
        textField.defaultTextAttributes = style
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        subscribeToKeyboardNotifications()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
        
    }
    
    
    
    func imagePickerController(_: UIImagePickerController, didFinishPickingMediaWithInfo Info: [String : Any])
    {
        //unwrapping the dictionary
        if let image = Info[UIImagePickerControllerOriginalImage] as? UIImage {
            imagePickerView.image = image
            imagePickerView.contentMode = UIViewContentMode.scaleAspectFit
            dismiss(animated: true, completion: nil)
            shareImage.isEnabled = self.imagePickerView.image != nil
        }
    }
    
    func imagePickerControllerDidCancel(_: UIImagePickerController)
    {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func pickAnImage(_ sender: Any) {
        chooseSourceType(sourceType: .photoLibrary)
    }
    
    @IBAction func pickAnImageFromCamera(_ sender: Any) {
        chooseSourceType(sourceType: .camera)
    }
    
    func chooseSourceType(sourceType: UIImagePickerControllerSourceType)
    {
        let pickerController = UIImagePickerController()
        pickerController.sourceType = sourceType
        pickerController.delegate = self
        self.present(pickerController, animated: true, completion: nil)
        
    }
    
    
    @objc func keyboardWillShow(_ notification:Notification) {
        if bottomTextField.isFirstResponder
        {
            view.frame.origin.y = 0 - getKeyboardHeight(notification)
        }
    }
    
    @objc func keyboardWillHide(_ notification:Notification) {
        view.frame.origin.y = 0
    }
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }
    
    func subscribeToKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications() {
        
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
        
    }
    
    func save() {
        // Create the meme
        let meme = Meme(topText: topTextField.text, bottomText: bottomTextField.text, originalImage: imagePickerView.image, memedImage: generateMemedImage())
        //adding the meme to the array
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        appDelegate.memes.append(meme)
        print(appDelegate.memes.count)
    }
    
    func generateMemedImage() -> UIImage {
        
        // Render view to an image
        configureToolBar(toolBar: bottomToolBar, status: true)
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        configureToolBar(toolBar: bottomToolBar, status: false)
        
        return memedImage
    }
    
    func configureToolBar(toolBar: UIToolbar, status: Bool)
    {
        toolBar.isHidden = status
        self.navigationController?.isNavigationBarHidden = status
    }
    
    @IBAction func shareAction(_ sender: Any) {
        
        let meme = generateMemedImage()
        let activityController = UIActivityViewController(activityItems: [meme], applicationActivities: nil)
        
        activityController.completionWithItemsHandler = {
            activity, completed, items, error in
            if completed {
                self.save()
                self.dismiss(animated: true, completion: nil)
            }
        }
        
        self.present(activityController, animated: true, completion: nil)
        
        
    }
    
    @IBAction func cancelAction(_ sender: Any) {
        //resetting all the fields
        self.bottomTextField.text = "BOTTOM"
        self.topTextField.text = "TOP"
        self.imagePickerView.image = nil
        shareImage.isEnabled = false
    }
    
    
}
// Mark: TextField delegate
extension ViewController: UITextFieldDelegate
{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if !textField.text!.isEmpty {
            textField.text = ""
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        subscribeToKeyboardNotifications()
        return true;
    }
}
