//
//  MemeDetailViewController.swift
//  meMeMe app
//
//  Created by Ohood Fahd on 12/4/17.
//  Copyright © 2017 Ohood Fahd. All rights reserved.
//

import UIKit

class MemeDetailViewController: UIViewController {

    
    var meme: Meme!
   
    @IBOutlet weak var memeImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.memeImage!.image = meme.memedImage
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
