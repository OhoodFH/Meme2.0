//
//  MemesTableViewController.swift
//  meMeMe app
//
//  Created by Ohood Fahd on 12/2/17.
//  Copyright © 2017 Ohood Fahd. All rights reserved.
//

import UIKit

class MemesTableViewController: UITableViewController {

    //array of memes
    var memes: [Meme]!
    
    @IBOutlet var memesTable: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        memes = appDelegate.memes
        print(memes.count)
        self.tableView.delegate = self
        self.tableView.dataSource = self
      /*  if memes.count==0
        {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let memeEditor = storyBoard.instantiateViewController(withIdentifier: "MemeEditor")
            let navController = UINavigationController(rootViewController: memeEditor)
            self.present(navController , animated: true, completion: nil)
        
        }*/
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return memes.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "memesCell")!
        let meme = self.memes[(indexPath as NSIndexPath).row]
        print("here")
        //setting the meme cell attribute
        cell.textLabel?.text = meme.topText!+"..."+meme.bottomText!
        cell.imageView?.image = meme.memedImage

        return cell
    }
   
  
    @IBAction func addMeme(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let memeEditor = storyBoard.instantiateViewController(withIdentifier: "MemeEditor")
        let navController = UINavigationController(rootViewController: memeEditor)
        self.present(navController , animated: true, completion: nil)
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let detailController = self.storyboard!.instantiateViewController(withIdentifier: "MemeDetailViewController") as! MemeDetailViewController
        detailController.meme = self.memes[(indexPath as NSIndexPath).row]
        self.navigationController!.pushViewController(detailController, animated: true)
    }

}
